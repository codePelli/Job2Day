package pack.job2day

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class activity_candidatos_gestionarpefil : AppCompatActivity() {

    lateinit var btnModificarPerfil : Button
    lateinit var btnEliminarPerfil : Button
    private lateinit var database: DatabaseReference
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_candidatos_gestionarpefil)
        auth = FirebaseAuth.getInstance()
        val userId = auth.currentUser?.uid
        database =
            FirebaseDatabase.getInstance("https://job2daympl-default-rtdb.europe-west1.firebasedatabase.app/")
                .getReference("Candidatos").child(userId!!)

        // Obtener referncias a los objetos de la interfaz del usuario

        btnModificarPerfil = findViewById(R.id.btn_modPerfil)
        btnEliminarPerfil = findViewById(R.id.btn_dltPerfil)

        // Listeners

        btnModificarPerfil.setOnClickListener{
            val intent = Intent(this, activity_candidatos_modificarperfil::class.java)
            startActivity(intent)
        }

        btnEliminarPerfil.setOnClickListener{
            eliminarPerfil()
        }
    }

    private fun eliminarPerfil() {
        auth = FirebaseAuth.getInstance()
        val userId = auth.currentUser?.uid
        val database = FirebaseDatabase.getInstance("https://job2daympl-default-rtdb.europe-west1.firebasedatabase.app/")
        val nodoCandidatos = database.getReference("Candidatos")

        // Muestra un cuadro de diálogo para confirmar la eliminación

        AlertDialog.Builder(this)
            .setTitle("Eliminar perfil")
            .setMessage("¿Estás seguro de que deseas eliminar tu perfil?")
            .setPositiveButton("SI") { _, _ ->

                // Eliminar el nodo del usuario en la base de datos

                nodoCandidatos.removeValue().addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Toast.makeText(this, "Perfil eliminado de la base de datos", Toast.LENGTH_SHORT).show()

                        // Eliminar la autenticación del usuario

                        auth.currentUser?.delete()?.addOnCompleteListener { authTask ->
                            if (authTask.isSuccessful) {
                                val intent = Intent(this, MainActivity::class.java)
                                startActivity(intent)
                                finish()
                            }
                        }
                    }
                }
            }
            .setNegativeButton("NO", null)
            .show()
    }

}