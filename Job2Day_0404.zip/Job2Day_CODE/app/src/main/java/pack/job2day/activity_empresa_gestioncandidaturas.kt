package pack.job2day

import EmpresaCandidatosAdapter
import android.content.ContentValues.TAG
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.ktx.Firebase

class activity_empresa_gestioncandidaturas : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var empresaCandidatosAdapter: EmpresaCandidatosAdapter
    private val candidatosList = ArrayList<Candidato>()
    private lateinit var candidaturasAdapter: EmpresaCandidatosAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_empresa_gestioncandidaturas)

        FirebaseApp.initializeApp(this)
        auth = Firebase.auth

        Log.d("Candidatos", "onCreate de activity_empresa_gestioncandidaturas")

        // Inicia el adaptador y el RecyclerView

        empresaCandidatosAdapter = EmpresaCandidatosAdapter(candidatosList)
        val recyclerViewCandidatos = findViewById<RecyclerView>(R.id.rvCandidaturas)
        recyclerViewCandidatos.adapter = empresaCandidatosAdapter
        recyclerViewCandidatos.layoutManager = LinearLayoutManager(this)

        // Obtén el userId actual y llama a la función obtenerCandidatos()

        val userId = FirebaseAuth.getInstance().currentUser?.uid
        if (userId != null) {
            Log.d("Candidatos", "UserId no es nulo: $userId")
            obtenerCandidatos(userId)
        }else{
            Log.d("Candidatos", "UserId es nulo")

        }
    }

    //TODO: Contenido de snapshot: DataSnapshot { key = Ofertas, value = null }
    // PROBLEMA CON LA CONSULTA A LA BBDD 100%?

    private fun obtenerCandidatos(userId: String) {
        val empresasRef = FirebaseDatabase.getInstance("https://job2daympl-default-rtdb.europe-west1.firebasedatabase.app").getReference("Empresas")
        empresasRef.child(userId).child("Ofertas").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {

                Log.d("Candidatos", "onDataChange ejecutado")
                Log.d("Candidatos", "Contenido de snapshot: $snapshot")

                if (snapshot.exists()) {

                    Log.e(TAG, "Snapshot no está vacia")

                    for (ofertaSnapshot in snapshot.children) {

                        Log.e(TAG, "Se ejecuta el 1r bucle for")

                        val ofertaAplicada = ofertaSnapshot.child("nombrePuesto").getValue(String::class.java) ?: ""
                        val candidatosSnapshot = ofertaSnapshot.child("Candidatos")


                        // Crea objeto Candidato con los datos de Firebase y añádelos a la lista de candidatos

                        for (candidatoSnapshot in candidatosSnapshot.children) {

                            Log.d("Candidatos", "2o Bucle for -> Cantidad de candidatos: ${candidatosList.size}")

                            val emailCandidato = candidatoSnapshot.getValue(String::class.java) ?: ""
                            val cvSnapshot = candidatoSnapshot.child("cv")
                            val nombreCandidato =
                                cvSnapshot.child("nombre").getValue(String::class.java) ?: ""

                            // Obtén los otros campos del CV desde cvSnapshot

                            val apellidosCandidato =
                                cvSnapshot.child("apellidos").getValue(String::class.java) ?: ""
                            val fechaNacimientoCandidato =
                                cvSnapshot.child("fechaNacimiento").getValue(String::class.java)
                                    ?: ""
                            val telefonoCandidato =
                                cvSnapshot.child("telefono").getValue(String::class.java) ?: ""
                            val paisCandidato =
                                cvSnapshot.child("pais").getValue(String::class.java) ?: ""
                            val poblacionCandidato =
                                cvSnapshot.child("poblacion").getValue(String::class.java) ?: ""
                            val formacionCandidato =
                                cvSnapshot.child("formacion").getValue(String::class.java) ?: ""
                            val experienciaCandidato =
                                cvSnapshot.child("experiencia").getValue(String::class.java)
                                    ?: ""
                            val conocimientosCandidato =
                                cvSnapshot.child("conocimientos").getValue(String::class.java)
                                    ?: ""
                            val otrosCandidato =
                                cvSnapshot.child("otros").getValue(String::class.java) ?: ""

                            val candidato = Candidato(
                                nombreCandidato,
                                emailCandidato,
                                ofertaAplicada,

                                // Campos del CV

                                apellidosCandidato,
                                fechaNacimientoCandidato,
                                telefonoCandidato,
                                paisCandidato,
                                poblacionCandidato,
                                formacionCandidato,
                                experienciaCandidato,
                                conocimientosCandidato,
                                otrosCandidato,
                            )
                            candidatosList.add(candidato)
                            Log.d("Candidatos", "Candidato añadido") // Añade este Log.d aquí
                        }
                    }

                    empresaCandidatosAdapter.notifyDataSetChanged()
                }
            }
            override fun onCancelled(error: DatabaseError) {
                Log.e(TAG, "Error al obtener las candidaturas: ${error.message}")
            }
        })
    }

}







