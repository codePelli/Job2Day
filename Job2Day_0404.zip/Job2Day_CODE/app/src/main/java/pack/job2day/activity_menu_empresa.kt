package pack.job2day

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class activity_menu_empresa : AppCompatActivity() {

    lateinit var btnGestionOfertas : Button
    lateinit var btnGestionCand : Button
    lateinit var BtnGestionPerfil : Button

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu_empresa)

        btnGestionOfertas = findViewById(R.id.btnGestionOfertas)
        btnGestionCand = findViewById(R.id.btnGestionCand)
        BtnGestionPerfil = findViewById(R.id.btnGestionPerfil)

        btnGestionOfertas.setOnClickListener{
            val intent = Intent (this, activity_empresa_gestionofertas::class.java)
            startActivity(intent)
        }

        btnGestionCand.setOnClickListener{
            val intent = Intent (this, activity_empresa_gestioncandidaturas::class.java )
            startActivity(intent)
        }
        BtnGestionPerfil.setOnClickListener{
            val intent = Intent (this, activity_empresa_gestionarperfil::class.java )
            startActivity(intent)
        }
    }
}