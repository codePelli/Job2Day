package pack.job2day

data class Candidato(

    val nombreCandidato: String? = null,
    val emailCandidato: String? = null,
    val ofertaAplicada: String? = null,
    val apellidosCandidato: String? = null,
    val fechaNacimientoCandidato: String? = null,
    val telefonoCandidato: String? = null,
    val paisCandidato: String? = null,
    val poblacionCandidato: String? = null,
    val formacionCandidato: String? = null,
    val experienciaCandidato: String? = null,
    val conocimientosCandidato: String? = null,
    val otrosCandidato: String? = null,
)
