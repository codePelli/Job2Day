package pack.job2day

import android.annotation.SuppressLint
import android.content.ContentValues
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class activity_empresa_crearoferta : AppCompatActivity() {

    lateinit var btnGuardarOferta: Button

    lateinit var auth: FirebaseAuth


    class Oferta {
        var nombrePuesto: String = ""
        var emailOferta: String = ""
        var fechaOferta: String = ""
        var descripcionOferta: String = ""
        var experienciaOferta: String = ""
        var formacionOferta: String = ""


        constructor()

        constructor(
            nombreOferta: String,emailOferta: String, fechaOferta: String, descripcionOferta: String,
            experienciaOferta: String, formacionOferta: String
        ) {
            this.nombrePuesto = nombreOferta
            this.emailOferta = emailOferta
            this.fechaOferta = fechaOferta
            this.descripcionOferta = descripcionOferta
            this.experienciaOferta = experienciaOferta
            this.formacionOferta = formacionOferta
        }
    }

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_empresa_crearoferta)

        FirebaseApp.initializeApp(this)

        val etNombrePuesto = findViewById<EditText>(R.id.etNombrePuesto)
        val etEmailEmpresa = findViewById<EditText>(R.id.etEmailEmpresa)
        val etFechaPuesto = findViewById<EditText>(R.id.etFechaPuesto)
        val multiDescripcionPuesto = findViewById<EditText>(R.id.multiDescripcionPuesto)
        val multiExperienciaPuesto = findViewById<EditText>(R.id.tvExpPuesto)
        val multiFormacionPuesto = findViewById<EditText>(R.id.tvFormacionPuesto)

        btnGuardarOferta = findViewById(R.id.btnGuardarOferta)

        btnGuardarOferta.setOnClickListener {

            val nombrePuesto = etNombrePuesto.text.toString()
            val emailEmpresa = etEmailEmpresa.text.toString()
            val fechaOferta = etFechaPuesto.text.toString()
            val descripcionOferta = multiDescripcionPuesto.text.toString()
            val experienciaOferta = multiExperienciaPuesto.text.toString()
            val formacionOferta = multiFormacionPuesto.text.toString()

            val oferta = Oferta(
                nombrePuesto, emailEmpresa, fechaOferta, descripcionOferta, experienciaOferta, formacionOferta
            )
            val userEmail = FirebaseAuth.getInstance().currentUser?.email
            if (userEmail != null) {
                val database = FirebaseDatabase.getInstance("https://job2daympl-default-rtdb.europe-west1.firebasedatabase.app/")
                val nodoEmpresas = database.getReference("Empresas")

                nodoEmpresas.orderByChild("email").equalTo(userEmail).addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        if (snapshot.exists()) {
                            for (usuarioSnapshot in snapshot.children) {
                                val nodoUsuario = usuarioSnapshot.ref

                                // Convierte la oferta en un mapa

                                val ofertaMap = mapOf(
                                    "nombrePuesto" to nombrePuesto,
                                    "emailEmpresa" to emailEmpresa,
                                    "fechaOferta" to fechaOferta,
                                    "descripcionOferta" to descripcionOferta,
                                    "experienciaOferta" to experienciaOferta,
                                    "formacionOferta" to formacionOferta
                                )

                                // Guarda las ofertas de trabajo en un nodo hijo de Ofertas

                                val nodoOferta = nodoUsuario.child("Ofertas").child(nombrePuesto)
                                nodoOferta.setValue(ofertaMap)
                                Toast.makeText(this@activity_empresa_crearoferta, "Se ha guardado la oferta.", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                    override fun onCancelled(error: DatabaseError) {
                        Log.e(ContentValues.TAG, "Error al leer el nodo del usuario: ${error.message}")
                    }
                })
            } else {
                Toast.makeText(this@activity_empresa_crearoferta, "No se pudo obtener el email del usuario. Asegúrese de haber iniciado sesión.", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
