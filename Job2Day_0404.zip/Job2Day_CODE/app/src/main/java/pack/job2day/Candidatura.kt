package pack.job2day

data class Candidatura(
    val nombrePuesto : String = "",
    val fechaOferta : String = "",
    val descripcionPuesto : String = "",
    val experienciaPuesto : String = "",
    val formacionPuesto : String = "",
    val otrosPuesto : String = "",
    val emailOferta  : String = ""
)
