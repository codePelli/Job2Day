package pack.job2day

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.ktx.Firebase
import java.util.regex.Pattern


class MainActivity : AppCompatActivity() {

    lateinit var editTextEmail: EditText
    lateinit var editTextPassword: EditText
    lateinit var btnActivityRegistroCandidato : Button
    lateinit var btnActivityRegistroEmpresa : Button
    lateinit var btnEntrarMenu : Button

    lateinit var auth: FirebaseAuth


    @SuppressLint("MissingInflatedId", "SuspiciousIndentation")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        FirebaseApp.initializeApp(this)

        auth = Firebase.auth

        // Obtiene las referencias a los objetos de la interfaz de usuario
        editTextEmail = findViewById(R.id.editTextPoblacionCreacv)
        editTextPassword = findViewById(R.id.editTextPassword)
        btnActivityRegistroCandidato = findViewById<Button>(R.id.btn_registroCandidato)
        btnActivityRegistroEmpresa = findViewById<Button>(R.id.btn_registroEmpresa)
        btnEntrarMenu = findViewById<Button>(R.id.btn_entrar)

        //Listeners botones
        btnActivityRegistroCandidato.setOnClickListener {
            val intent = Intent(this, activity_reg_candidato::class.java)
            startActivity(intent)
        }
        btnActivityRegistroEmpresa.setOnClickListener {
            val intent = Intent(this, activity_reg_empresa::class.java)
            startActivity(intent)
        }

        btnEntrarMenu.setOnClickListener {
            val email = editTextEmail.text.toString()
            val password = editTextPassword.text.toString()
            //val encodedEmail = android.util.Base64.encodeToString(email.toByteArray(), android.util.Base64.NO_WRAP)

            // LOGIN EMPRESA O CANDIDATO

            if (validacionEmail(email) && validacionPassword(password)) {

                // Busca si el usuario es una empresa

                val empresasRef = FirebaseDatabase.getInstance("https://job2daympl-default-rtdb.europe-west1.firebasedatabase.app"
                ).getReference("Empresas")
                empresasRef.orderByChild("email").equalTo(email)
                    .addListenerForSingleValueEvent(object : ValueEventListener {
                        override fun onDataChange(snapshot: DataSnapshot) {
                            if (snapshot.exists()) {

                                // Inicia sesión como empresa

                                auth.signInWithEmailAndPassword(email, password)
                                    .addOnCompleteListener(this@MainActivity) { task ->
                                        if (task.isSuccessful) {

                                            // Inicio de sesión exitoso, redirige al usuario a la actividad de empresas

                                            val intent = Intent(
                                                this@MainActivity,
                                                activity_menu_empresa::class.java
                                            )
                                            startActivity(intent)
                                            finish()
                                        } else {

                                            // Si el inicio de sesión falla, muestra un mensaje al usuario

                                            Toast.makeText(
                                                this@MainActivity, "Autenticación fallida.",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                    }

                            } else {

                                // Busca si el usuario es un candidato

                                val candidatosRef =
                                    FirebaseDatabase.getInstance("https://job2daympl-default-rtdb.europe-west1.firebasedatabase.app"
                                ).getReference("Candidatos")
                                candidatosRef.orderByChild("email").equalTo(email)
                                    .addListenerForSingleValueEvent(object : ValueEventListener {
                                        override fun onDataChange(snapshot: DataSnapshot) {
                                            if (snapshot.exists()) {

                                                // Inicia sesión como candidato

                                                auth.signInWithEmailAndPassword(email, password)
                                                    .addOnCompleteListener(this@MainActivity) { task ->
                                                        if (task.isSuccessful) {

                                                            // Inicio de sesión exitoso, redirige al usuario a la actividad de candidatos

                                                            val intent = Intent(
                                                                this@MainActivity,
                                                                activity_menu_candidatos::class.java
                                                            )
                                                            startActivity(intent)
                                                            finish()
                                                        } else {

                                                            // Si el inicio de sesión falla, muestra un mensaje al usuario

                                                            Toast.makeText(
                                                                this@MainActivity,
                                                                "Autenticación fallida.",
                                                                Toast.LENGTH_SHORT
                                                            ).show()
                                                        }
                                                    }

                                            } else {

                                                // Si el usuario no existe en ningún nodo, muestra un mensaje al usuario

                                                Toast.makeText(
                                                    this@MainActivity, "Usuario no registrado.",
                                                    Toast.LENGTH_SHORT
                                                ).show()
                                            }
                                        }

                                        override fun onCancelled(error: DatabaseError) {

                                            // Si hay un error al buscar en la base de datos, muestra un mensaje al usuario

                                            Toast.makeText(
                                                this@MainActivity, "Error al buscar usuario.",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                    })
                            }
                        }

                        override fun onCancelled(error: DatabaseError) {

                            // Si hay un error al buscar en la base de datos, muestra un mensaje al usuario

                            Toast.makeText(
                                this@MainActivity, "Error al buscar usuario.",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    })

            } else {

                // Si los datos del formulario no son válidos, muestra un mensaje al usuario

                Toast.makeText(
                    this@MainActivity, "Datos de inicio de sesión no válidos.",
                    Toast.LENGTH_SHORT
                ).show()
            }

        }

    }

    private fun validacionEmail(email: String): Boolean {
        val emailPattern = Pattern.compile("^\\w+@[a-zA-Z_]+?\\.[a-zA-Z]{2,3}\$")
        val matcher = emailPattern.matcher(email)
        return matcher.matches()
    }

    private fun validacionPassword(password: String): Boolean {
        val passwordPattern = Pattern.compile("^(?=.*[0-9])(?=.*[a-zA-Z])(?=\\S+$).{8,}$")
        val matcher = passwordPattern.matcher(password)
        return matcher.matches()
    }
    private fun updateUI(user: FirebaseUser?) {

    }

}
