package pack.job2day

import MyAdapter
import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class activity_card_lista : AppCompatActivity() {

    lateinit var auth: FirebaseAuth

    private lateinit var dbref: DatabaseReference
    private lateinit var ofertasAdapter: MyAdapter
    private lateinit var ofertasRecyclerView: RecyclerView
    private lateinit var ofertasArrayList: ArrayList<activity_empresa_crearoferta.Oferta>

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_candidatos_busquedaempleo)

        ofertasArrayList = arrayListOf<activity_empresa_crearoferta.Oferta>()
        ofertasAdapter = MyAdapter(ofertasArrayList)

        ofertasRecyclerView = findViewById(R.id.ofertasList)
        ofertasRecyclerView.apply {
            layoutManager = LinearLayoutManager(this@activity_card_lista)
            adapter = ofertasAdapter
        }

        getUserData()
    }

    private fun getUserData() {
        val dbref = FirebaseDatabase.getInstance("https://job2daympl-default-rtdb.europe-west1.firebasedatabase.app/").getReference("Empresas")
        dbref.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    Log.d("CardViewDebug", "Snapshot de 'Empresas' existe, leyendo ofertas...")
                    for (userSnapshot in snapshot.children) {
                        Log.d("CardViewDebug", "Leyendo usuario: ${userSnapshot.key}")
                        val ofertasSnapshot = userSnapshot.child("Ofertas")
                        for (ofertaSnapshot in ofertasSnapshot.children) {
                            Log.d("CardViewDebug", "Leyendo oferta: ${ofertaSnapshot.key}")
                            val oferta = ofertaSnapshot.getValue(activity_empresa_crearoferta.Oferta::class.java)
                            if (oferta != null) {
                                ofertasArrayList.add(oferta)
                                Log.d("CardViewDebug", "Oferta agregada: ${oferta.nombrePuesto}")
                            } else {
                                Log.d("CardViewDebug", "Oferta nula en ofertaSnapshot: ${ofertaSnapshot.key}")
                            }
                        }
                    }

                    runOnUiThread {
                        ofertasAdapter.notifyDataSetChanged()
                        Log.d("CardViewDebug", "Adaptador actualizado con ${ofertasArrayList.size} elementos")
                    }
                } else {
                    Log.d("CardViewDebug", "Snapshot de Empresas vacío")
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("CardViewDebug", "Error en ValueEventListener: ${error.message}")
            }
        })
    }

}
