package pack.job2day

data class Ofertas(

    var id: String? = null,
    var nombreEmpresa: String? = null,
    var nombrePuesto: String? = null,
    var fechaOferta: String? = null,
    var descripcionOferta: String? = null,
    var experienciaOferta: String? = null,
    var formacionOferta: String? = null,
    var emailEmpresa: String? = null,
    var candidatos: List<Candidatura>? = null
)

