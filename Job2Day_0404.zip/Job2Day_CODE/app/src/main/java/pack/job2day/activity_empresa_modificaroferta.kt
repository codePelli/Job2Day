package pack.job2day

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class activity_empresa_modificaroferta : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_empresa_modificaroferta)
    }
}