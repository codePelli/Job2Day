package pack.job2day

import CandidaturasAdapter
import android.content.ContentValues.TAG
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.ktx.Firebase

class activity_candidatos_gestioncandidaturas : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    lateinit var recyclerView: RecyclerView
    lateinit var adapter: CandidaturasAdapter
    val candidaturasList = ArrayList<Candidatura>()
    private lateinit var candidaturasAdapter: CandidaturasAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_candidatos_gestioncandidaturas)

        FirebaseApp.initializeApp(this)
        auth = Firebase.auth

        // Inicializa el adaptador y RecyclerView

        candidaturasAdapter = CandidaturasAdapter(candidaturasList)
        val recyclerViewCandidaturas = findViewById<RecyclerView>(R.id.recyclerView)
        recyclerViewCandidaturas.adapter = candidaturasAdapter
        recyclerViewCandidaturas.layoutManager = LinearLayoutManager(this)

        val userId = FirebaseAuth.getInstance().currentUser?.uid

        // Llama a la función para obtener las candidaturas

        if (userId != null) {
            obtenerCandidaturas(userId)
        }


    }
    private fun obtenerCandidaturas(userId: String) {
        val empresasRef = FirebaseDatabase.getInstance("https://job2daympl-default-rtdb.europe-west1.firebasedatabase.app").getReference("Empresas")
        empresasRef.orderByChild("Candidatos/${userId.replace(".", ",")}/cv").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {

                    for (empresaSnapshot in snapshot.children) {
                        for (ofertaSnapshot in empresaSnapshot.child("Ofertas").children) {
                            val nombrePuesto = ofertaSnapshot.child("nombrePuesto").getValue(String::class.java) ?: ""
                            val fechaOferta = ofertaSnapshot.child("fechaOferta").getValue(String::class.java) ?: ""
                            val emailOferta = empresaSnapshot.child("email").getValue(String::class.java) ?: ""
                            val candidatura = Candidatura(nombrePuesto, fechaOferta, emailOferta)
                            candidaturasList.add(candidatura)

                            Log.d(TAG, "Candidatura: $candidatura")
                        }
                    }

                    // Notifica al adaptador que los datos han cambiado

                    candidaturasAdapter.notifyDataSetChanged()
                } else {
                    Toast.makeText(this@activity_candidatos_gestioncandidaturas, "No hay candidaturas.", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onCancelled(error: DatabaseError) {

                Log.e(TAG, "Error al obtener las candidaturas: ${error.message}")
            }
        })
    }

}
