import android.content.ContentValues.TAG
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import pack.job2day.Candidato
import pack.job2day.R

class EmpresaCandidatosAdapter(private val candidatosList: List<Candidato>) :
    RecyclerView.Adapter<EmpresaCandidatosAdapter.EmpresaCandidatosViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EmpresaCandidatosViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(
            R.layout.activity_empresa_candidatoscard,
            parent, false
        )
        return EmpresaCandidatosViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: EmpresaCandidatosViewHolder, position: Int) {
        val currentItem = candidatosList[position]
        Log.d(TAG, "onBindViewHolder - posición: $position, candidato: $currentItem") // Añade este mensaje de registro

        holder.tvNombreCandidato.text = currentItem.nombreCandidato
        holder.tvEmailCandidato.text = currentItem.emailCandidato
        holder.tvOfertaAplicada.text = currentItem.ofertaAplicada

        holder.btnVerCV.setOnClickListener {

            // TODO: Implementa la lógica para mostrar el CV del candidato

        }
    }

    override fun getItemCount(): Int {
        return candidatosList.size
    }

    class EmpresaCandidatosViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvNombreCandidato: TextView = itemView.findViewById(R.id.tvCandidatoNombre)
        val tvEmailCandidato: TextView = itemView.findViewById(R.id.tvCandidatoEmail)
        val tvOfertaAplicada: TextView = itemView.findViewById(R.id.tvCandidatoOfertaAplicada)
        val btnVerCV: Button = itemView.findViewById(R.id.btnCandidatoVerCV)
    }
}
