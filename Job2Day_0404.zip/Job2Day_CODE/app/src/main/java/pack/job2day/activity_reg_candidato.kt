package pack.job2day

import android.annotation.SuppressLint
import android.content.ContentValues.TAG
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.ktx.Firebase
import java.util.regex.Pattern




class activity_reg_candidato : AppCompatActivity() {
    lateinit var auth: FirebaseAuth

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reg_candidato)
        FirebaseApp.initializeApp(this)
        auth = Firebase.auth

        // Configurar el "Ya tengo una cuenta en Job2Day" para volver atrás

        val hiperenlace = findViewById<TextView>(R.id.tv_hiperenlace2)

        // Recopila la información del usuario

        val user = Firebase.auth.currentUser
        user?.let {
            // Name, email address, and profile photo Url
            val name = it.displayName
            val email = it.email
            // The user's ID, unique to the Firebase project. Do NOT use this value to
            // authenticate with your backend server, if you have one. Use
            // FirebaseUser.getIdToken() instead.
            val uid = it.uid
        }

        hiperenlace.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)

        }

        Toast.makeText(this, "Rellena todos los campos", Toast.LENGTH_SHORT).show()

        // Obtiene las referencias a los objetos de la interfaz de usuario

        val editTextEmail = findViewById<EditText>(R.id.editTextPoblacionCreacv)
        val editTextPassword = findViewById<EditText>(R.id.editTextPassword)
        val editTextNombre = findViewById<EditText>(R.id.editTextNombre)
        val editTextApellido = findViewById<EditText>(R.id.editTextApellidoMod)
        val editTextTelefono = findViewById<EditText>(R.id.editTextTelefono)
        val editTextPais = findViewById<EditText>(R.id.editTextPais)
        val editTextPoblacion = findViewById<EditText>(R.id.editTextPoblacionCreacv)


        // Obtiene una referencia al botón y agrega un escuchador de eventos

        val buttonGuardar = findViewById<Button>(R.id.buttonRegistro)

        // Usuario empresa para Firebase

        class Candidato {
            var email: String = ""
            var password: String = ""
            var nombre: String = ""
            var apellido: String = ""
            var telefono: String = ""
            var pais: String = ""
            var poblacion: String = ""

            constructor()

            constructor(
                email: String,
                password: String,
                nombre: String,
                apellido: String,
                telefono: String,
                pais: String,
                poblacion: String
            ) {
                this.email = email
                this.password = password
                this.nombre = nombre
                this.apellido = apellido
                this.telefono = telefono
                this.pais = pais
                this.poblacion = poblacion

            }

        }

        // Acciones que realiza el botón REGISTRAR

        buttonGuardar.setOnClickListener {

            // Crea un objeto Empresa con los datos del formulario

            val email = editTextEmail.text.toString()
            val password = editTextPassword.text.toString()
            val nombre = editTextNombre.text.toString()
            val apellido = editTextApellido.text.toString()
            val telefono = editTextTelefono.text.toString()
            val pais = editTextPais.text.toString()
            val poblacion = editTextPoblacion.text.toString()

            // Validar los campos rellenados

            if (!camposRellenados(email, password, nombre, apellido, telefono, pais, poblacion)) {
                Toast.makeText(this, "Rellena todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (!validacionPassword(password)) {
                editTextPassword.error =
                    "La contraseña debe tener al menos 8 caracteres y contener, al menos, una letra y un número"
                return@setOnClickListener
            }

            if (!validacionEmail(email)) {
                Toast.makeText(this, "Email incorrecto o ya en uso", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (!validacionTelefono(telefono)) {
                Toast.makeText(
                    this,
                    "El número de teléfono debe contener sólo 9 números",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            val candidato = Candidato(email, password, nombre, apellido, pais, poblacion, telefono)

            // Obtiene una referencia a la base de datos de Firebase y guarda el objeto Empresa

            val userId = FirebaseAuth.getInstance().currentUser?.uid
            val uid = userId ?: ""
            val database = FirebaseDatabase.getInstance("https://job2daympl-default-rtdb.europe-west1.firebasedatabase.app/")
            val ref = database.getReference("Candidatos")
            ref.child(uid).setValue(candidato)

            Toast.makeText(this, "Se ha registrado correctamente", Toast.LENGTH_SHORT).show()

            //https://firebase.google.com/docs/auth/android/password-auth

            auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        // Sign in success, update UI with the signed-in user's information
                        Log.d(TAG, "createUserWithEmail:success")
                        val user = auth.currentUser
                        updateUI(user)
                    } else {
                        // If sign in fails, display a message to the user.
                        Log.w(TAG, "createUserWithEmail:failure", task.exception)
                        Toast.makeText(
                            baseContext, "Authentication failed.",
                            Toast.LENGTH_SHORT
                        ).show()
                        updateUI(null)
                    }
                }

            // Vuelve al Main_activity

            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

    }

    // Funciones de comprobación de los datos insertados

    private fun validacionTelefono(telefono: String): Boolean {
        return !TextUtils.isEmpty(telefono) && TextUtils.isDigitsOnly(telefono) && telefono.length == 9
    }

    private fun camposRellenados(
        email: String,
        password: String,
        nombre: String,
        apellido: String,
        telefono: String,
        pais: String,
        poblacion: String
    ): Boolean {
            return !TextUtils.isEmpty(email) && !TextUtils.isEmpty(password) && !TextUtils.isEmpty(
            nombre
        ) &&
                !TextUtils.isEmpty(apellido) && !TextUtils.isEmpty(telefono) && !TextUtils.isEmpty(
            pais
        ) &&
                !TextUtils.isEmpty(poblacion)
    }

    private fun validacionEmail(email: String): Boolean {
        val emailPattern = Pattern.compile("^\\w+@[a-zA-Z_]+?\\.[a-zA-Z]{2,3}\$")
        val matcher = emailPattern.matcher(email)
        return matcher.matches()
    }

    private fun validacionPassword(password: String): Boolean {
        val passwordPattern = Pattern.compile("^(?=.*[0-9])(?=.*[a-zA-Z])(?=\\S+$).{8,}$")
        val matcher = passwordPattern.matcher(password)
        return matcher.matches()
    }

    private fun updateUI(user: FirebaseUser?) {
    }
}



