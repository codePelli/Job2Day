import android.content.ContentValues
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import pack.job2day.Candidatura
import pack.job2day.R
import pack.job2day.activity_empresa_crearoferta

class MyAdapter(private val list: ArrayList<activity_empresa_crearoferta.Oferta>) :
    RecyclerView.Adapter<MyAdapter.MyViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(
            R.layout.activity_card_layout,
            parent, false
        )
        itemView.layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT

        Log.d("CardViewDebug", "onCreateViewHolder")
        return MyViewHolder(itemView)

    }

    // Almacenará los candidatos que apliquen

    var candidatos: HashMap<String, String> = HashMap()

    // Agrega la referencia a la base de datos de "Empresas"

    val database =
        FirebaseDatabase.getInstance("https://job2daympl-default-rtdb.europe-west1.firebasedatabase.app/")
    val nodoEmpresas = database.getReference("Empresas")

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem = list[position]
        holder.tvNombreCarta.text = currentItem.nombrePuesto
        holder.tvEmpresaCarta.text = currentItem.fechaOferta

        Log.d(
            "CardViewDebug",
            "onBindViewHolder: posición $position, nombrePuesto: ${currentItem.nombrePuesto}"
        )

        holder.btnDetallesCarta.setOnClickListener {
            val oferta = list[position]
            val inflater = LayoutInflater.from(holder.itemView.context)
            val view = inflater.inflate(R.layout.oferta_detail_dialog, null)

            // Datos de la oferta del dialog

            view.findViewById<TextView>(R.id.tvNombrePuesto).text = oferta.nombrePuesto
            view.findViewById<TextView>(R.id.tvFechaPuesto).text = oferta.fechaOferta
            view.findViewById<TextView>(R.id.tvDescripcionPuesto).text = oferta.descripcionOferta
            view.findViewById<TextView>(R.id.tvExpPuesto).text = oferta.experienciaOferta
            view.findViewById<TextView>(R.id.tvFormacionPuesto).text = oferta.formacionOferta


            AlertDialog.Builder(holder.itemView.context)
                .setTitle("Detalles de la oferta")
                .setView(view)
                .setPositiveButton("Cerrar") { dialog, _ ->
                    dialog.dismiss()
                }
                .show()
        }


        holder.btnAplicarCarta.setOnClickListener {
            val userEmail = FirebaseAuth.getInstance().currentUser?.email
            val empresaEmail = currentItem.emailOferta
            val database = FirebaseDatabase.getInstance("https://job2daympl-default-rtdb.europe-west1.firebasedatabase.app/")
            val nodoCandidatos = database.getReference("Candidatos")
            val nodoEmpresas = database.getReference("Empresas")

            if (userEmail != null) {
                nodoCandidatos.orderByChild("email").equalTo(userEmail).addListenerForSingleValueEvent(object :
                    ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        if (snapshot.exists()) {
                            for (usuarioSnapshot in snapshot.children) {
                                val nodoUsuario = usuarioSnapshot.ref

                                // Agrega el correo electrónico del usuario a la lista de candidatos

                                candidatos[usuarioSnapshot.key!!] = userEmail

                                // Actualiza los datos en la base de datos

                                nodoUsuario.child("OfertasAplicadas").child(currentItem.nombrePuesto).setValue(
                                    Candidatura(currentItem.nombrePuesto, currentItem.fechaOferta, currentItem.emailOferta)
                                )

                                Toast.makeText(holder.itemView.context, "Has aplicado a la oferta.", Toast.LENGTH_SHORT).show()

                                // Obtiene el nodo de la empresa que ha creado la oferta

                                nodoEmpresas.orderByChild("email").equalTo(currentItem.emailOferta).addListenerForSingleValueEvent(object :
                                    ValueEventListener {
                                    override fun onDataChange(snapshot: DataSnapshot) {
                                        if (snapshot.exists()) {
                                            for (empresaSnapshot in snapshot.children) {
                                                val nodoEmpresa = empresaSnapshot.ref
                                                val nodoOfertas = nodoEmpresa.child("Ofertas")

                                                // Busca la oferta por el nombre del puesto

                                                val nodoOferta = nodoOfertas.child(currentItem.nombrePuesto)
                                                nodoOferta.addListenerForSingleValueEvent(object : ValueEventListener {

                                                    override fun onDataChange(ofertaSnapshot: DataSnapshot) {
                                                        if (ofertaSnapshot.exists()) {
                                                            for (oferta in ofertaSnapshot.children) {
                                                                val nodoOferta = oferta.ref

                                                                // Agrega el candidato a la oferta en el nodo de Candidatos dentro de la oferta

                                                                // TODO: insertar el email con un punto y no una coma

                                                                val encodedEmail = userEmail.replace(".", ",")

                                                                nodoOferta.child("Candidatos").child(encodedEmail).child("cv").setValue(usuarioSnapshot.child("cv").value)
                                                            }
                                                        }
                                                    }

                                                    override fun onCancelled(ofertaError: DatabaseError) {
                                                        Log.e(ContentValues.TAG, "Error al leer el nodo de la oferta: ${ofertaError.message}")
                                                    }
                                                })
                                            }
                                        }
                                    }

                                    override fun onCancelled(error: DatabaseError) {
                                        Log.e(ContentValues.TAG, "Error al leer el nodo de la empresa: ${error.message}")
                                    }
                                })

                            }
                        }
                    }

                    override fun onCancelled(error: DatabaseError) {
                        Log.e(ContentValues.TAG, "Error al leer el nodo del usuario: ${error.message}")
                    }
                })
            }
        }

    }

    override fun getItemCount(): Int {
        Log.d("CardViewDebug", "getItemCount: ${list.size}")
        return list.size
    }

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val btnAplicarCarta: Button = itemView.findViewById(R.id.btnAplicarCarta)
        val btnDetallesCarta: Button = itemView.findViewById(R.id.btDetallesCarta)
        val tvNombreCarta: TextView = itemView.findViewById(R.id.tvNombreCarta)
        val tvEmpresaCarta: TextView = itemView.findViewById(R.id.tvEmpresaCarta)

    }

}


